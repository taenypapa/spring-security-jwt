package com.agile.demo.biz.account;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/api/accounts")
public class AccountController {
}
