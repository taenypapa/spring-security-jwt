import logo from './logo.svg';
import './App.css';
import Button from 'react-bootstrap/Button';
import axios from 'axios'


function App() {

  function getMe(){
    axios.get('http://localhost:8080/me',
    {
      headers:{
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ0ZXN0MSIsInNjb3BlIjpbInJlYWQiLCJ3cml0ZSJdLCJuYW1lIjoidGVzdCIsInVzcklkIjoidGVzdDEiLCJleHAiOjE2ODI1OTE1MjAsImF1dGhvcml0aWVzIjpbIlNVUEVSIl0sImp0aSI6ImVmOTRmOGE1LTk0YWQtNGUzZS1hNzU1LWUwYzgzY2Q2NTFkMyIsImNsaWVudF9pZCI6ImNsaWVudF9pZCJ9.0gdHzgl4j8UpZquaFGwBWBSJaPwZ7bcD9Asu1UgAT6o'
      }
    }
    ).then(res => {
      console.log(res);
    })
  }

  function getToken(){
    const originData = 'client_id:client_secret';
    console.log(btoa(originData));

    axios.post('http://localhost:8080/oauth/token?grant_type=password&username=test1&password=test2',
      {},
      {
        headers:{ 
          'Authorization': 'Basic '+btoa(originData)} 
      }
    ).then( res => {
      console.log(res);
    })
  }
  

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <Button onClick={getToken}>토큰얻기</Button>
        <Button onClick={getMe}>토큰확인</Button>
      </header>
    </div>
  );
}

export default App;
